# Policies

## Returns

Unused items in their original packaging can come back within 30 days of delivery.

## Damaged items

Send a photo of the item and its packaging within 14 days of delivery.
