# Order desk

Answers a pottery shop's order questions from its order system and its own policies.

## Documents it asks you for

It works from these, so have them ready:

- **`policies`**: Your returns, refunds and shipping policies, as you show them to customers.
  - Needed before it runs
  - File types: md, txt, pdf
  - A made-up example: `samples/policies.md`

The examples in `samples/` are made up: try the assistant on them first, then give it your own.

To hand it a document: in Claude Code, type `@` and the file's path in your message; in a claude.ai Project, add it to the Project's knowledge; in ChatGPT or another chat app, attach it to the chat; through the API, put its text in your message.

## Set it up

**Quickest:** open this unzipped folder in VS Code (or any editor), open a terminal in it (VS Code: *Terminal → New Terminal*; or macOS Terminal: `cd` into the folder), then run:

```
bash setup.sh
```

(Optionally `bash setup.sh /path/to/your/project`.) On macOS, double-clicking `setup.sh` in Finder will *not* run it — use a terminal as above. The script places the files and checks prerequisites, then prints the only steps it can't do for you.

Prefer to do it by hand? Full steps, where `<name>` is `order-desk`:

## How to use this assistant — step by step

**In this bundle:**

- `SKILL.md` — the assistant itself
- `README.md` — this guide
- `AGENTS.md` — the same instructions, in the open format some agent tools auto-load
- `.mcp.json` / `.cursor/mcp.json` / `.vscode/mcp.json` — ready-to-use MCP server config, one shape per client
- `skills/refund-rules/SKILL.md` — the refund-rules skill, included
- `skills/refund-rules/references/refund-limits.md` — a file the refund-rules skill reads

**Skills included** (in `skills/`, part of this purchase):

- **refund-rules** (`skills/refund-rules/`)

**MCP servers it needs** — you run these locally with **your own** credentials; the marketplace holds no connection:

- **orders**: find_order, refund_order — Reads the shop's orders and refunds one.
  - you provide: SHOP_API_KEY

### Claude Code

1. Unzip this bundle into your project folder.
2. Copy `SKILL.md` to `.claude/skills/<name>/SKILL.md`, where `<name>` is the `name:` at the top of `SKILL.md` (create the folders if needed).
3. Copy each skill folder this bundle includes into `.claude/skills/` too:
   - `skills/refund-rules/`
4. Keep `.mcp.json` at the project root (it is already filled in with the server command).
5. Provide your **own** credentials. Easiest: re-run `setup.sh` with the file path and it bakes it into `.mcp.json` for you (no export, no editing):
   - `bash setup.sh SHOP_API_KEY=/path/to/your/file`
   - (Manual alternative: `export NAME=...` in the shell that starts Claude Code.)
6. Start Claude Code in that folder.
7. Use the assistant normally. It uses the tools **only when you ask** — it never acts on its own.

### claude.ai

claude.ai on the web cannot start this assistant's MCP servers: each one is a program that runs on your computer. There the assistant works without its tools; for them, follow the Claude Code steps above or the Claude Desktop steps below.

1. Create a Project and paste the text below the `---` header of `SKILL.md` into the Project's instructions.
2. Paste each required skill's `SKILL.md` text into the instructions too, below the assistant's.
3. Paste each file a skill reads below that skill's text, with the file's path on the line above it:
   - `skills/refund-rules/references/refund-limits.md`
4. Chat with the Project — same reactive behaviour.

### Claude Desktop

Claude Desktop starts MCP servers on your computer, so the assistant has its tools there.

1. Run `setup.sh` with your own credentials, as for Claude Code, so your project's `.mcp.json` holds them:
   - `bash setup.sh SHOP_API_KEY=/path/to/your/file`
2. In Claude Desktop, open *Settings → Developer → Edit Config*, add each entry below from that `.mcp.json` under `"mcpServers"`, and restart Claude Desktop:
   - `orders` (find_order, refund_order)
3. Create a Project as in the claude.ai steps above, and chat with it.

### API

1. Send the `SKILL.md` body as the system message.
2. Load the referenced skills via the Agent Skills mechanism.
3. Point your MCP client at the same command/args from `.mcp.json`, with your own credentials in the environment.

### Also compatible

Both formats are open standards, not tied to Anthropic tooling — this assistant also works as-is with:

- **Cursor** — `SKILL.md` as a rule, `.cursor/mcp.json` in this bundle is pre-filled
- **Windsurf** — same idea via Cascade rules + `.mcp.json`
- **Cline** (VS Code extension) — custom instructions + its MCP settings
- **VS Code agent mode** — `.vscode/mcp.json` in this bundle is pre-filled
- **Gemini CLI** and most other agent CLIs — same system-prompt + MCP pattern
- **Any SDK** (Anthropic, OpenAI, ...) — see the quickstarts below
- **Any local agent runtime** that reads a system prompt and/or an MCP config

### Quickstarts

Both read `SKILL.md`'s body (the text below the `---` header) as the system prompt:

**Python (Anthropic SDK):**

```python
import anthropic
skill = open("SKILL.md").read().split("---", 2)[-1].strip()
client = anthropic.Anthropic()
reply = client.messages.create(model="claude-sonnet-5", max_tokens=1024,
    system=skill, messages=[{"role": "user", "content": "your input here"}])
print(reply.content[0].text)
```

**JavaScript (OpenAI SDK):**

```js
import OpenAI from "openai";
import { readFileSync } from "fs";
const skill = readFileSync("SKILL.md", "utf8").split("---").slice(2).join("---").trim();
const client = new OpenAI();
const reply = await client.chat.completions.create({ model: "gpt-4o",
  messages: [{ role: "system", content: skill }, { role: "user", content: "your input here" }] });
console.log(reply.choices[0].message.content);
```

**Claude Agent SDK:** same idea as Claude Code above — the Agent SDK reads Agent Skills from `.claude/skills/` in its working directory, so this assistant can be embedded as a component of a larger agent instead of run standalone.


Reactive by design: it acts only on what you send, never on its own. The tools are used only to fulfil what you just asked.
