---
name: refund-rules
description: Decide whether an order can be refunded, and how much, under the shop's refund limits.
---

Before offering a refund, find the order with find_order and check its date and value against
references/refund-limits.md. Offer refund_order only for an order inside those limits, and say
which limit applies.
