# Refund limits

- Orders up to $40: refund without a return, within 14 days of delivery.
- Orders over $40: refund once the item is back, within 30 days of delivery.
- Seconds and gift cards: no refund.
