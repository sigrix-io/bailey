#!/usr/bin/env bash
# One-shot setup for a non-technical buyer. Idempotent; safe to
# re-run.
#
# Usage:
#   bash setup.sh                       # install into current dir
#   bash setup.sh /path/to/project      # install elsewhere
#   bash setup.sh NAME=/path/to/cred    # also wire a credential
#                                       # file in for you (no manual
#                                       # export needed)
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PROJECT="$PWD"
CREDS=()
for a in "$@"; do
  case "$a" in
    *=*) CREDS+=("$a") ;;
    *) if [ -d "$a" ]; then PROJECT="$a"; fi ;;
  esac
done
safe_cp() {
  [ "$1" -ef "$2" ] && return 0
  cp "$1" "$2"
}
place_config() {
  [ "$1" -ef "$2" ] && return 0
  mkdir -p "$(dirname "$2")"
  if [ -f "$2" ] && [ ! -e "$2.before-sigrix" ] && ! cmp -s "$1" "$2" 2>/dev/null; then
    cp "$2" "$2.before-sigrix"
    echo "  note: your earlier $3 is kept as $3.before-sigrix"
  fi
  cp "$1" "$2"
}
echo "Installing into: $PROJECT"

mkdir -p "$PROJECT/.claude/skills/order-desk"
safe_cp "$HERE/SKILL.md" "$PROJECT/.claude/skills/order-desk/SKILL.md"
echo "  ok: SKILL.md placed"
mkdir -p "$PROJECT/.claude/skills/refund-rules"
safe_cp "$HERE/skills/refund-rules/SKILL.md" "$PROJECT/.claude/skills/refund-rules/SKILL.md"
if [ -d "$HERE/skills/refund-rules/references" ]; then
  mkdir -p "$PROJECT/.claude/skills/refund-rules/references"
  for f in "$HERE/skills/refund-rules/references/"*; do
    if [ -f "$f" ]; then safe_cp "$f" "$PROJECT/.claude/skills/refund-rules/references/$(basename "$f")"; fi
  done
fi
echo "  ok: the refund-rules skill placed"
for f in '.mcp.json' '.cursor/mcp.json' '.vscode/mcp.json'; do
  if [ -f "$HERE/$f" ]; then place_config "$HERE/$f" "$PROJECT/$f" "$f"; fi
done
echo '  ok: .mcp.json, .cursor/mcp.json and .vscode/mcp.json placed in the project'
for kv in "${CREDS[@]:-}"; do
  [ -z "$kv" ] && continue
  k="${kv%%=*}"; v="${kv#*=}"
  if [ -e "$v" ]; then v="$(cd "$(dirname "$v")" && pwd)/$(basename "$v")"; fi
  if grep -q "\"$k\": \"\"" "$PROJECT/.mcp.json"; then
    for f in '.mcp.json' '.cursor/mcp.json' '.vscode/mcp.json'; do
      if [ -f "$PROJECT/$f" ]; then sed -i.bak "s|\"$k\": \"\"|\"$k\": \"$v\"|" "$PROJECT/$f" && rm -f "$PROJECT/$f.bak"; fi
    done
    echo "  ok: baked $k into the MCP configuration (no manual export needed)"
  else
    echo "  note: $k is not a blank slot in .mcp.json (already set?)"
  fi
done
command -v 'uvx' >/dev/null 2>&1 || echo '  WARNING: uvx not found — the MCP server needs it (install it first)'
missing=()
for v in SHOP_API_KEY; do
  if grep -q "\"$v\": \"\"" "$PROJECT/.mcp.json" 2>/dev/null && [ -z "${!v:-}" ]; then missing+=("$v"); fi
done
if [ "${#missing[@]}" -gt 0 ]; then
  echo "  TODO: still need credentials for: ${missing[*]}"
  echo "        re-run: bash setup.sh ${missing[0]}=/path/to/your/file"
fi
echo ""
echo "Almost done — steps only you can do:"
echo "  1. Start Claude Code in $PROJECT and approve the project MCP server when prompted."
echo "Then just talk to the assistant — it acts only when you ask."
